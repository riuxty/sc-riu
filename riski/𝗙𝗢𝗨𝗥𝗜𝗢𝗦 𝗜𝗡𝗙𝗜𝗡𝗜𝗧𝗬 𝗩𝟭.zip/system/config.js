//========HELO FRIEND========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6283128817881"] 
global.namabot = 'Infinity Crash'
//======================
global.mess = { 
owner: '*Maaf, Anda Bukan Owner*',
premium: '*Maaf, Anda Bukan Premium*',
succes: '*Succesfull*'
}
//======================