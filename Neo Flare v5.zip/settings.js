/*═══════════════════════════════════════════════════════
 *  ⌬  YT NeoShiroko Labs
 *═══════════════════════════════════════════════════════
 *  🌐  Website     : https://www.neolabsofficial.my.id
 *  ⌨︎  Developer   : https://zass.cloud
 *  ▶︎  YouTube     : https://www.youtube.com/@zassci_desu
 *  ⚙︎  Panel Murah : pteroku-desu.zass.cloud
 *
 *  ⚠︎  Mohon untuk tidak menghapus watermark ini
 *═══════════════════ © 2025 Zass Desuta ─════════════════════
 */

const fs = require('fs')
const chalk = require('chalk')

//——————————[ Set Owner ]——————————//
global.ytname = "https://www.youtube.com/@zassci_desu"
global.location = "Abydos High School"
global.ownername = "Zass Desuta"
global.ownernumber = '6285250058150' 
global.email = "desu.core@zass.id" // gmail.com

//——————————[ Set Bot ]——————————//
global.botname = '𝙽𝚎𝚘 𝙵𝚕𝚊𝚛𝚎 あ⁩'
global.versi = '5.0'
global.foot = '© ᴍᴀᴅᴇ ʙʏ ᴢᴀss ᴅᴇsᴜᴛᴀ'
global.idSaluran = "120363420619530273@newsletter"
global.namach = "𝙽𝚎𝚘'𝚂 𝙻𝚊𝚋𝚜 𝙲𝚑."
global.aiUsageCount = global.aiUsageCount || {};
global.hias = "➤"
global.pairing = "needloli"

//——————————[ Set Sticker ]——————————//
global.packname = ':: 𝙽𝚎𝚘 𝙵𝚕𝚊𝚛𝚎 ::'
global.author = `\nWaBot By NeoShiroko Labs`
global.themeemoji = '🪀'
global.wm = "⫹⫺ 𝚈𝚃 𝙽𝚎𝚘𝚂𝚑𝚒𝚛𝚘𝚔𝚘 𝙻𝚊𝚋𝚜"

//——————————[ Set Link ]——————————//
global.link = "https://whatsapp.com/channel/0029Vb6w7eO9sBIEUYRgeC30"
global.namagc = "Marketplace¹ || Zass Official"
global.linkgc = "https://chat.whatsapp.com/Bvdic3yrpFh5kTkk5oc5G0"
global.web = "https://www.neolabsofficial.my.id"
global.prefa = ['!','.','#','💐']

//——————————[ Set Payment ]——————————//
global.dana = "Tidak Tersedia" // Isi no dana mu
global.gopay = "Tidak Tersedia" // Isi no gopay mu
global.ovo = "Tidak Tersedia" // Isi no ovo mu
global.qris = "https://link_qr_mu.desu" // pakai fitur .tourl untuk ubah foto ke link
global.an = {
  dana: "Nama dana",
  gopay: "Nama Gopay",
  ovo: "Nama Ovo"
}

//——————————[ Set Automatic ]——————————//
global.pay = {
  apikey: "CiaaTopup_blablabla_APIKEY_KAMU",
  fee: 300,
  metode: "QRISFAST",
  expired: Date.now() + (30 * 60 * 1000)
}

/* Link: https://www.ciaatopup.my.id
Gatau caranya? gini caranya 👇
- Step1 Daftar akun
Klik url web diatas lalu daftar/register untuk mendapatkan apikey kamu.

- Step2 Dapatkan apikey
Klik navbar, jika kalian menggunakan hp kik garis tiga di pojok kiri atas lalu klik "API Key" nah salin apikey nya abis tu tempel di atas.

- Step3 Verifikasi Akun
Kamu harus memverifikasi akun untuk mengaktifkan h2h(api) kamu sepenuhnya agar bisa di akses oleh bot.
Caranya tinggal kembali ke web ciaa topup lalu klik icon profil di pojok kanan atas dan klik "Support" untuk menghubungi tim support melalui WhatsApp.

Chat aja admin nya ketik gini:
"Halo mimin aku mau verifikasi akun.
Username: username kamu
Kode Referral: ZASS.ID6194
Udah itu aja, nitip salam dari zass senpai😉"

Udah tinggal tunggu pengajuan kamu diproses oleh admin nya dan duarr fitur buy otomatis nya sudah aktif plus siap pakai👌 Btw wajib sertakan kode referral ya untuk mendapatkan pelayanan yg lebih baik😏 Ohya untuk fitur .buypanel itu menggunakan apikey panel v1 di bawah ya scroll aja tar keliatan.

~ Sekian dan... au lah kokoro nangis lagi jir
*/

//——————————[ Set Pushkontak ]——————————//
global.delayjpm = 1000
global.delaypushkontak = 6000

//——————————[ Manage Vercell ]——————————//
global.vercelToken = "2A5CIYutvRA2c8lUurA9iwkK" //Your Vercel Token

//——————————[ Manage GitHub ]——————————//
global.githubToken = "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" //Your GitHub Token
global.githubUsername = "NeoS-Labs" //Your GitHub Username

//——————————[ Media Url ]——————————//
global.gif = "https://files.catbox.moe/22w9jb.mp4"
global.imgthumb = "https://files.catbox.moe/jizop0.jpeg" 
global.imgmenu = "https://files.cloudkuimages.guru/images/SWXIM6un.jpg" 
global.imgdoc = "https://files.catbox.moe/lmbhlo.jpeg" // ukuran 1280 × 450
global.logo = "https://files.catbox.moe/0i1pef.jpeg" 
global.vn = "https://files.catbox.moe/ub4w7z.mpeg" 
global.thumb_welcome = "https://files.catbox.moe/05ot73.jpeg"

//——————————[ Api Panel V1 ]——————————//
global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://domainmu.com"
global.apikey = "" // Isi api ptla
global.capikey = "" // Isi api ptlc

//——————————[ Api Panel V2 ]——————————//
global.egg2 = "15" // Isi id egg
global.nestid2 = "5" // Isi id nest
global.loc2 = "1" // Isi id location
global.domain2 = "https://domainmu2.com"
global.apikey2 = "-" // Isi api ptla
global.capikey2 = "-" // Isi api ptlc

//——————————[ Api Panel PV ]——————————//
global.egg3 = "15" // Isi id egg
global.nestid3 = "5" // Isi id nest
global.loc3 = "1" // Isi id location
global.domain3 = "https://domainmu-privatepanel.vip"
global.apikey3 = "-" // Isi api ptla
global.capikey3 = "-" // Isi api ptlc

//——————————[ Set Massage ]——————————//
global.loadreact = "🧿"
global.mesg = {
  slr: "Fitur ini khusus reseller! Silahkan hubungi owner untuk membeli akses",
  pv: "*[ Warm System ]* Fitur ini khusus di private chat",
  gc: "*[ Warm System ]* Fitur ini khusus grup om—____—",
  own: "*[ Warm System ]* Sok asikk fitur ini khusus manusia tertamvan",
  adm: "*[ Warm System ]* Fitur ini khusus ateminnn",
  botadm: "Jadiin admin dulu",
  load: "bentar....",
  err: "Terjadi kesalahan, coba lagi suatu saat nanti..."
}
  

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})