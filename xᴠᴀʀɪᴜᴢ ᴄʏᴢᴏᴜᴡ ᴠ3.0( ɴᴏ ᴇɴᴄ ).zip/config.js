module.exports = {
  BOT_TOKEN: "7578997166:AAGeg7b3uM1DmqWi5z1tpuOo6IAY0v-2H7I",
};